// Programmer: Justin Brown
// Date: 12/05/2023
// Course: CS-300


// All required header files 
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

// Define vector
struct Course {
    std::string courseNumber;
    std::string courseTitle;
    std::vector<std::string> coursePrerequisites;
};


// Function to load data into nto data structure
void LoadDataStructure(std::vector<Course>& courseData, const std::string& filename) {

    // Open the file
    std::ifstream file(filename);

    // Parse course data from the file and insert into vector
    if (file.is_open()) {
      
        std::string courseNumber, courseTitle, coursePrerequisites;
        while (file >> courseNumber >> courseTitle) {
            Course course;
            course.courseNumber = courseNumber;
            course.courseTitle = courseTitle;

            while (file >> coursePrerequisites) {
                course.coursePrerequisites.push_back(coursePrerequisites);
            }

            courseData.push_back(course);
        }
    }
    else {
        std::cout << "Unable to open the file.";
    }
}

// Function to print course list in alphanumeric order
void PrintCourseList(const std::vector<Course>& courseData) {
    std::vector<Course> sortedCourses = courseData;
    std::sort(sortedCourses.begin(), sortedCourses.end(),
        [](const Course& a, const Course& b) {
            return a.courseNumber < b.courseNumber;
        });

    for (const Course& course : sortedCourses) {
        std::cout << course.courseNumber << ", " << course.courseTitle << std::endl;
    }
}

// Function to print course information
void PrintCourseInformation(const std::vector<Course>& courseData, const std::string& courseNumber) {
    for (const Course& course : courseData) {
        if (course.courseNumber == courseNumber) {
            std::cout << course.courseNumber << ", " << course.courseTitle << std::endl;
            if (!course.coursePrerequisites.empty()) {
                std::cout << "coursePrerequisites:" << std::endl;
                for (const std::string& coursePrerequisites : course.coursePrerequisites) {
                    std::cout << coursePrerequisites << std::endl;
                }
            }
            return;
        }
    }
    std::cout << "Course not found.";
}
// Main menu
int main() {
    std::vector<Course> courseData;
    std::string filename;

    while (true) {
        std::cout << "1. Load Data Structure." << std::endl;
        std::cout << "2. Print Course List." << std::endl;
        std::cout << "3. Print Course." << std::endl;
        std::cout << "4. Exit" << std::endl;

        int choice;
        if (!(std::cin >> choice)) {
            std::cout << "Invalid input.";
        }

        switch (choice) {
        // Prompts user to input file containing data
        case 1:
            std::cout << "Enter course data file: ";
            std::cin >> filename;
            LoadDataStructure(courseData, filename);
            break;
            // Checks to see if course data was loaded, else prints list
        case 2:
            if (courseData.empty()) {
                std::cout << "Course data not loaded.";
            }
            else {
                PrintCourseList(courseData);
            }
            break;
            // Checks to see if course data was loaded, else prints course info
        case 3:
            if (courseData.empty()) {
                std::cout << "Course data not loaded.";
            }
            else {
                std::string courseNumber;
                std::cout << "Enter course numer: ";
                std::cin >> courseNumber;
                PrintCourseInformation(courseData, courseNumber);
            }
            break;

            // Case if user exits program 
        case 4:
            std::cout << "Exiting program";
            return 0;

            // Case if invalid option is input
        default:
            std::cout << "Invalid choice";

        }
    }

    return 0;
}